<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.15';
$suitecrm_timestamp = '2020-06-11 12:00:00';
