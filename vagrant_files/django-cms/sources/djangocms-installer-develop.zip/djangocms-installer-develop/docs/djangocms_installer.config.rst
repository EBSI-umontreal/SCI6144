djangocms_installer.config package
==================================

Submodules
----------

djangocms_installer.config.internal module
##########################################

.. automodule:: djangocms_installer.config.internal
    :members:
    :undoc-members:
    :show-inheritance:

djangocms_installer.config.settings module
##########################################

.. automodule:: djangocms_installer.config.settings
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
###############

.. automodule:: djangocms_installer.config
    :members:
    :undoc-members:
    :show-inheritance:
