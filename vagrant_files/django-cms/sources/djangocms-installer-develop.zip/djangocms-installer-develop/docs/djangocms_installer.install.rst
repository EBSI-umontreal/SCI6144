djangocms_installer.install package
===================================

Module contents
---------------

.. automodule:: djangocms_installer.install
    :members:
    :undoc-members:
    :show-inheritance:
