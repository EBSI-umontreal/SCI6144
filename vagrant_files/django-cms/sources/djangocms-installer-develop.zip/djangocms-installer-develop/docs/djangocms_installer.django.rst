djangocms_installer.django package
==================================

Module contents
---------------

.. automodule:: djangocms_installer.django
    :members:
    :undoc-members:
    :show-inheritance:
