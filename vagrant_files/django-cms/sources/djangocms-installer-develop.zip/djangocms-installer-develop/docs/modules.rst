Package documentation
=====================

.. toctree::
   :maxdepth: 4

   djangocms_installer
