---
name: "\U0001F389 Feature request"
about: Share your idea, let's discuss it!
title: ''
labels: 'type: feature'
assignees: ''

---

<!--
Please fill in each section to help maintainers to be helpful and quick to respond.
-->

## Description

<!--
Describe the feature in general terms.
-->

## Use cases

<!--
What use cases these feature will address?
-->

## Proposed solution

<!--
A clear and concise description of what you want to happen.
-->

## Alternatives

<!--
A clear and concise description of any alternative solutions or features you've considered.
-->

## Additional information

<!--
Add any other information.
-->
