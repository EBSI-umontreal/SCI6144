__author__ = "Iacopo Spalletti"
__email__ = "i.spalletti@nephila.it"
__version__ = "1.3.0dev1"
